﻿
using System.ComponentModel;
using System.Reflection;
using System.Reflection.Metadata;

class Program
{
    public static List<String> _lista = new List<string>();

    static void Main(string[] args)
    {
        bool showMenu = true;
        while (showMenu)
        {
            showMenu = MainMenu();
        }
    }

    static bool MainMenu()
    {
        Console.Clear();
        Console.WriteLine("MicroKernel UDEC DEMO");
        Console.WriteLine("=====================");
        Console.WriteLine("Escoje una opción:");
        Console.WriteLine("1) Mostrar plugins");
        Console.WriteLine("2) Ejecutar plugins");
        Console.WriteLine("3) Salir");
        Console.Write("\r\nSeleccione una opción: ");

        switch (Console.ReadLine())
        {
            case "1":
                ReadPlugins();
                return true;
            case "2":
                RunPlugins();
                return true;
            case "3":
                return false;
            default:
                return true;
        }
    }




    static void RunPlugins()
    {
        if (_lista.Count == 0)
        {
            Console.WriteLine("Primero debe leer los plugins");
        }
        else
        {
            try
            {

                foreach (string plugin in _lista)
                {


                    Assembly asm = Assembly.LoadFile(@"C:\udec_demos\Microkernel\CoreApp\plugins\" + plugin);
                    Type type = asm!.GetType("plugin.Program");

                    if (type != null)
                    {
                        MethodInfo methodInfo = type.GetMethod("operacion");
                        if (methodInfo != null)
                        {
                            object result = null;
                            ParameterInfo[] parameters = methodInfo.GetParameters();
                            object classInstance = Activator.CreateInstance(type, null);
                            if (parameters.Length == 0)
                            {
                                result = methodInfo.Invoke(classInstance, null);
                            }
                            else
                            {
                                object[] parametersArray = new object[] { 1, 2 };

                                result = methodInfo.Invoke(classInstance, parametersArray);
                                Console.WriteLine("Resultado " + plugin + " --->" + Convert.ToString(result));
                            }
                        }
                    }

                }
            }


            catch (IOException e)
            {
                Console.WriteLine("No se encuentra el archivo");
                Console.WriteLine(e.Message);
            }
        }


        Console.ReadKey();


    }

    static void ReadPlugins()
    {
        _lista.Clear();
        try
        {

            foreach (string line in File.ReadLines("C:\\udec_demos\\Microkernel\\CoreApp\\plugins.udec"))
            {

                if (!line.StartsWith("#"))
                {
                    _lista.Add(line);
                    Console.WriteLine(line);
                }
            }

        }
        catch (IOException e)
        {
            Console.WriteLine("The file could not be read:");
            Console.WriteLine(e.Message);
        }

        Console.ReadKey();


    }

}









