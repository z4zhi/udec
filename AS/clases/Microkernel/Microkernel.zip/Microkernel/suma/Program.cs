﻿namespace plugin
{
    public class Program
    {
        public int operacion(int a , int b)
        {
            return a + b;
        }
    }
}

