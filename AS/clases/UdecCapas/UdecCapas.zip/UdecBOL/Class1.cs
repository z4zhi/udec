﻿namespace UdecBOL
{
    public class Class1
    {

    }
}