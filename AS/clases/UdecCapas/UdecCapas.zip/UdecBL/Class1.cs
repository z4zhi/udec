﻿namespace UdecBL
{
    public class Class1
    {

    }
}