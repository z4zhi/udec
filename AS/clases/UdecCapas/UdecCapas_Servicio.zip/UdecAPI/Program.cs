using UdecBL;
using UdecBOL;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!");

app.MapGet("/PersonasV1", () => { 
    var lista = new PersonaBL().listaPersonas();
    return lista;

});

app.Run();
