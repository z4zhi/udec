# README

El código contiene 3 funciones para cada búsqueda. Cada función recibe un vector "v" y un número entero "n".

## Compilación y Ejecución

Compilación:

$ g++ busquedas.cpp

Ejecución:

$ ./a.out

El programa se ejecuta con dos tipos de análisis experimental:

1. Tamaño de entrada variable (100, 1000, ..., 100000000), número a buscar constante (tamaño+1).
2. Número a buscar variable (0, 10000000, 20000000 , ..., 100000000), tamaño de entrada constante (100000000).

Para ejecutar el análisis experimental 2, proporcionar cualquier argumento adicional, ejemplo:

$ ./a.out a
